function checkname() {
    let login_username = document.getElementById("login-username").value;
    let login_password = document.getElementById("login-password").value;

    if (login_username == "" && login_password == "") {
        document.getElementById("login-username-msg").innerHTML = "Enter username";
        document.getElementById("login-password-msg").innerHTML = "Enter password";

        return false;
    }

}

