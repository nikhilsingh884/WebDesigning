function checkblank() {
    let fullname = document.getElementById("fullname").value;
    let username = document.getElementById("username").value;
    let email = document.getElementById("email").value;
    let mobile = document.getElementById("mobile").value;
    let password = document.getElementById("password").value;
    let confirmpassword = document.getElementById("confirm-password").value;

    if (fullname == "" && username == "" && email == "" && mobile == "" && password == "" && confirmpassword == "") {
        document.getElementById("fullname-msg").innerHTML = "Enter Fullname";
        return false;

        document.getElementById("username-msg").innerHTML = "Enter username";

        document.getElementById("email-msg").innerHTML = "Enter email";

        document.getElementById("mobile-msg").innerHTML = "Enter mobile no.";

        document.getElementById("password-msg").innerHTML = "Enter password";

        document.getElementById("confirmpassword-msg").innerHTML = "Enter conifrm password";
        return false;
    }
}