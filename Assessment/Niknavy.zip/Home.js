
// -----------ham-menu-------------

$(document).ready(function () {
    $(".toggle").click(function () {
        $(".ham-menu").slideToggle(250);
        $(".overlay").toggle();
    });
});


// -----------ham-menu-------------

// var button = document.getElementById("btn");
// var modal = document.querySelector(".modal");
// let overlay = document.querySelector('.overlay');
// let closeBtn = document.querySelector('.closeBtn');



// button.addEventListener("click", function () {
//     modal.classList.add("modal-d-block");
//     overlay.classList.add("overlay-show");
// })

// overlay.addEventListener("click", function () {
//     overlay.classList.remove('overlay-show');
// })